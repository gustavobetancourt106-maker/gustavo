/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package numerosprimos;

/**
 *
 * @author LEN
 */
public class PrincipalPrimos {// Clase principal desde donde se ejecuta el programa

    public static void main(String[] args) { // Método principal (punto de inicio del programa)

        NumerosPrimos obj = new NumerosPrimos(); // Se crea un objeto de la clase NumerosPrimos

        obj.mostrarPrimos(); // Se llama al método que imprime los números primos
    }
}

