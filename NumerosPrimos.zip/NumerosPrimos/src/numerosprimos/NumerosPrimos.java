/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numerosprimos;

/**
 *
 * @author LEN
 */
public class NumerosPrimos {// Definición de la clase llamada NumerosPrimos

    /**
     * @param args the command line arguments
     */
    
     public void mostrarPrimos() { // Método que se encarga de mostrar los números primos

        for (int i = 2; i <= 50; i++) { // Bucle que recorre los números del 2 al 50

            boolean esPrimo = true; // Variable que asume que el número es primo

            for (int j = 2; j < i; j++) { // Bucle que verifica si el número tiene divisores
                if (i % j == 0) { // Si el número i es divisible entre j
                    esPrimo = false; // Entonces no es primo
                    break; // Sale del bucle porque ya no es necesario seguir comprobando
                }
            }

            if (esPrimo) { // Si después de las comprobaciones sigue siendo primo
                System.out.println(i); // Imprime el número en la consola
            }
        }
    }
}